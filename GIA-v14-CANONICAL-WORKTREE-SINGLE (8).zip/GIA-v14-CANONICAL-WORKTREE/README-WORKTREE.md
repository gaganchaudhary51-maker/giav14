# GIA v14 Canonical Worktree — Handoff Index

Start in `giav14-main/`. Governance, carry-forward notes, and file hashes are in the sibling folders:
- `governance/WORKTREE-GOVERNANCE.md`
- `governance/CHANGELOG.md`
- `reports/PREVIOUS-MERGE-REPORT.md`
- `manifests/SOURCE-SHA256-MANIFEST.csv`

This is a single portable ZIP for continuing work. It does not directly alter the user's Windows PC. Back up the existing project before copying files into it.

Latest carry-forward: `reports/PHASE-2-AGENT-EXECUTION-WIRING.md` documents the authenticated team-run endpoint and test status (140 backend tests passed; live provider not verified).


## Latest BUILD-IT update — 2026-10-24
The canonical `giav14-main/` tree now includes the isolated `hrgen_universal_monorepo/` voice integration slice and optional async callback scheduling for Swarn Auditor and Lucas Growth. Existing personal chats, RAG, and memory were not migrated or reset.

Verified: 145 canonical backend tests and 8 voice-slice tests pass; Python syntax compilation passes. The frontend production build is still blocked because npm dependency installation did not complete in this environment. Live model/Supabase/telephony providers and Docker runtime remain unverified. See `reports/RELEASE-BUILD-AND-INTEGRATION-STATUS.md`.
