# Carry-forward change log

- Imported the existing `GIA-v14-MAIN-MERGED.zip` into one canonical `giav14-main/` folder.
- Kept governance and integrity documentation outside the application source folder.
- Preserved the source files as present in the input package; no application code was edited in this packaging step.
- Personal RAG/memory records were not migrated or seeded by this packaging step.
- Verification performed: input ZIP test, output ZIP test, file inventory, SHA-256 manifest.
- Not claimed here: live provider connectivity, telephony/WhatsApp/Supabase end-to-end tests, frontend production build, Windows launcher execution, or a full secrets scan.

- Phase 2: added authenticated `/api/agents/run` sequential team invocation with per-agent results and audit events.
- Added regression tests for ownership, lifecycle guard, alias resolution, unknown-agent rejection, and partial failures.
- Verification: 140 backend tests passed; live provider integration remains unverified and disabled by default.

- Phase 2 UI wiring: added Studio execution form that creates an owned task, transitions it to EXECUTING, calls `/agents/run` for the selected pod's mapped canonical agent, renders per-agent output/errors, and records final task state.
- Added missing frontend API methods for Studio configuration, prompt evolution, task status, and team execution.
- Provider remains opt-in; unavailable provider errors are surfaced. No personal RAG/memory data was imported, migrated, reset, or seeded.
- Verification: backend test suite passed (140 tests). Frontend production build could not be verified in this environment because npm dependency installation was interrupted by execution time limit.

- Fixed Studio run lifecycle handling: approval-required tasks are left awaiting approval and are not executed; successful/partially successful agent runs can transition to EXECUTED, and all-failed runs transition to FAILED.
- Re-ran backend regression suite after lifecycle fix: 140 passed.
- Frontend build remains unverified because TypeScript/Vite dependencies are not fully installed in this execution environment.

- Release hardening: added opt-in live integration smoke script, release verification script, environment-variable example, and CI workflow for backend tests + frontend production build.
- Added mocked safety tests for signed VoIP webhook validation, provider-secret non-disclosure, render-only WhatsApp template handling, and local Supabase fallback.
- Latest backend suite: 145 passed. Live integrations were skipped due missing credentials. Frontend production build remains blocked here by missing npm-installed TypeScript/Vite dependencies.

## Build-it hardening — 2026-10-24
- Added opt-in async interval callback jobs for Swarn Auditor and Lucas Growth with bearer auth, idempotency keys, HTTPS/loopback URL validation, and no personal-memory/tool attachment.
- Added fail-closed production webhook auth when the webhook token is missing, constant-time token comparison, and bounded audio-upload reads.
- Bound Docker Compose port 8000 to host loopback by default.
- Added isolated voice-slice tests and included them in release verification.
- Verification: 145 canonical backend tests passed; 8 voice-slice tests passed; Python compilation passed.
- Frontend production build remains blocked by incomplete npm dependency installation; live provider, Supabase, Docker and telephony checks remain unverified.
