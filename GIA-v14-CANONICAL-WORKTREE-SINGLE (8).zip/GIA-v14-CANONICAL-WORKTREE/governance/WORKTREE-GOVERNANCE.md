# GIA v14 Worktree Governance

## Canonical layout
- `giav14-main/` — the single application source tree; keep the project name and existing internal folder names.
- `governance/` — worktree policy, change log, verification records, and source integrity notes.
- `manifests/` — SHA-256 inventory for source files and package.
- `reports/` — carried-forward merge report and verification caveats.

## Rules
1. This package is the canonical handoff snapshot for continuing work in one worktree; do not create another nested app/project root.
2. Preserve existing personal RAG, memory, chats, and user data. Do not migrate, reset, delete, seed, or rewrite their contents without explicit permission.
3. Code changes touching RAG/memory must be reviewed separately from data. Back up before any local replacement.
4. Keep credentials out of source control. Use local environment files and documented placeholders; never publish real keys.
5. Keep secrets, runtime databases, uploads, logs, caches, virtual environments, `node_modules`, and build outputs out of portable source ZIPs unless explicitly requested.
6. Keep the project bound to loopback by default; no public exposure without explicit approval.
7. All external integrations must be marked unconfigured until a live end-to-end test passes.
8. Agent profiles are not proof of execution. Record provider calls, tool invocations, permissions, errors, cancellation, and run status.
9. Changes must be traceable: record files changed, tests run, results, known gaps, and package SHA-256.
10. Do not overwrite the user's Windows folder automatically. Make a backup before copying the canonical source into `C:\Users\pc\Desktop\giav14-main`.

## Release gates
- Source ZIP integrity passes.
- Backend test suite passes in the target supported runtime.
- Frontend production build passes.
- Startup smoke test passes on Windows.
- Secrets scan passes and no real credentials are bundled.
- RAG/memory data isolation is verified.
- Provider/telephony/WhatsApp/Supabase status reflects actual tests, not assumptions.

11. Studio execution must create an owner-scoped task, move it through the task state machine, show provider errors, and never report completion without a successful provider result.

12. Approval-required tasks must remain pending approval; Studio must never bypass approval gates.
13. Task status updates must follow the backend lifecycle graph; completed agent runs may transition to EXECUTED only after the endpoint returns results.

14. Release packages must distinguish mocked integration tests from live provider tests and explicitly record missing credentials.
15. Never send live WhatsApp messages or initiate real calls during smoke tests without a consented recipient/test resource and explicit approval.
