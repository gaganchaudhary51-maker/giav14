"""P5 regression tests for the optional, approval-gated Hermes bridge."""
from fastapi.testclient import TestClient

from app.main import app
from app.auth.security import issue_token
from app.tasks.store import task_store
from app.integrations import hermes


def _approved_task(owner_id: str):
    task = task_store.create(
        "Run unit tests for the current branch",
        "standard",
        ["qa"],
        True,
        owner_id=owner_id,
    )
    task = task_store.update(task["id"], "APPROVED", owner_id=owner_id)
    assert task["status"] == "APPROVED"
    assert task["approval_required"] is False
    return task


def test_hermes_status_requires_authentication():
    client = TestClient(app)
    assert client.get("/api/integrations/hermes/status").status_code == 401


def test_hermes_handoff_rejects_unapproved_task(monkeypatch):
    client = TestClient(app)
    owner = "p5-owner-unapproved"
    token = issue_token(owner)
    task = task_store.create("Check tests", "standard", ["qa"], False, owner_id=owner)
    monkeypatch.setattr(hermes, "status", lambda: {"configured": True, "reachable": True})
    response = client.post(
        "/api/integrations/hermes/handoff",
        headers={"Authorization": f"Bearer {token}"},
        json={"task_id": task["id"]},
    )
    assert response.status_code == 409


def test_hermes_handoff_requires_task_ownership(monkeypatch):
    client = TestClient(app)
    task = _approved_task("p5-real-owner")
    monkeypatch.setattr(hermes, "status", lambda: {"configured": True, "reachable": True})
    response = client.post(
        "/api/integrations/hermes/handoff",
        headers={"Authorization": f"Bearer {issue_token('p5-other-owner')}"},
        json={"task_id": task["id"]},
    )
    assert response.status_code == 404


def test_hermes_handoff_only_sends_minimal_envelope(monkeypatch):
    client = TestClient(app)
    task = _approved_task("p5-approved-owner")
    monkeypatch.setattr(hermes, "status", lambda: {"configured": True, "reachable": True})
    submitted = []
    monkeypatch.setattr(
        hermes, "submit_handoff",
        lambda item: (submitted.append(item) or {"accepted": True, "job_id": "remote-job-123", "mode": "handoff_only"}),
    )
    response = client.post(
        "/api/integrations/hermes/handoff",
        headers={"Authorization": f"Bearer {issue_token('p5-approved-owner')}"},
        json={"task_id": task["id"]},
    )
    assert response.status_code == 200, response.text
    assert response.json()["accepted"] is True
    assert response.json()["mode"] == "handoff_only"
    assert submitted[0]["id"] == task["id"]


def test_hermes_http_envelope_does_not_forward_owner_or_secrets(monkeypatch):
    task = _approved_task("p5-envelope-owner")
    monkeypatch.setattr(hermes, "_settings", lambda: ("https://hermes.example", "bridge-secret"))
    captured = {}

    class FakeResponse:
        def raise_for_status(self):
            return None
        def json(self):
            return {"accepted": True, "job_id": "remote-job-456"}

    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def post(self, url, headers, json):
            captured.update({"url": url, "headers": headers, "json": json})
            return FakeResponse()

    monkeypatch.setattr(hermes.httpx, "Client", FakeClient)
    result = hermes.submit_handoff(task)
    assert result["accepted"] is True
    envelope = captured["json"]
    assert envelope["mode"] == "handoff_only"
    assert envelope["requires_remote_approval"] is True
    assert "owner_id" not in envelope
    assert "password" not in envelope
    assert "token" not in envelope


def test_hermes_handoff_disabled_when_bridge_is_not_configured(monkeypatch):
    client = TestClient(app)
    task = _approved_task("p5-disabled-owner")
    monkeypatch.setattr(hermes, "status", lambda: {"configured": False, "reachable": False})
    response = client.post(
        "/api/integrations/hermes/handoff",
        headers={"Authorization": f"Bearer {issue_token('p5-disabled-owner')}"},
        json={"task_id": task["id"]},
    )
    assert response.status_code == 503


def test_hermes_rejects_non_https_remote_url(monkeypatch):
    monkeypatch.setenv("HERMES_ADAPTER_URL", "http://example.com")
    monkeypatch.setenv("HERMES_ADAPTER_TOKEN", "test-token")
    try:
        hermes._settings()
        assert False, "Expected insecure remote HTTP URL to be rejected"
    except hermes.HermesNotConfigured:
        pass
