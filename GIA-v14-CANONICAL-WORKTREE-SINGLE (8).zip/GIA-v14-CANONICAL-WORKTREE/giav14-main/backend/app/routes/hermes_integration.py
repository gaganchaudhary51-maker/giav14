"""Explicitly gated Hermes handoff endpoints."""
from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel, Field

from app.auth.security import verify_token
from app.audit.log import audit_log
from app.tasks.store import task_store
from app.integrations import hermes

router = APIRouter(prefix="/integrations/hermes", tags=["integrations"])


def _auth(authorization: str | None) -> str:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Authentication required")
    uid = verify_token(authorization[7:])
    if not uid:
        raise HTTPException(401, "Invalid or expired token")
    return uid


class HandoffRequest(BaseModel):
    task_id: str = Field(min_length=1, max_length=200)


@router.get("/status")
def get_status(authorization: str | None = Header(default=None)):
    _auth(authorization)
    return hermes.status()


@router.post("/handoff")
def handoff(payload: HandoffRequest, authorization: str | None = Header(default=None)):
    uid = _auth(authorization)
    task = task_store.get(payload.task_id, owner_id=uid)
    if not task:
        raise HTTPException(404, "Task not found")
    if task.get("status") != "APPROVED" or task.get("approval_required", False):
        raise HTTPException(409, "Task must have explicit, recorded approval before Hermes handoff")
    status = hermes.status()
    if not status.get("configured"):
        raise HTTPException(503, "Hermes bridge is not configured")
    if not status.get("reachable"):
        raise HTTPException(503, "Hermes bridge is not reachable")
    try:
        result = hermes.submit_handoff(task)
    except hermes.HermesNotConfigured:
        raise HTTPException(503, "Hermes bridge is not configured")
    except hermes.HermesBridgeError:
        audit_log.append("HERMES_HANDOFF_FAILED", uid, {"task_id": task["id"]})
        raise HTTPException(502, "Hermes bridge did not accept the handoff")
    audit_log.append("HERMES_HANDOFF_ACCEPTED", uid, {
        "task_id": task["id"], "job_id": result.get("job_id"), "mode": "handoff_only"
    })
    return {"task_id": task["id"], **result, "note": "Handoff accepted; remote execution still requires approval in the Hermes environment."}
