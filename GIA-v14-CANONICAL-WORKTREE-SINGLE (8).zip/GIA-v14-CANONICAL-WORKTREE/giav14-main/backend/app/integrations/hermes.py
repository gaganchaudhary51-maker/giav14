"""Optional, isolated Hermes bridge client.

GIA never imports or executes the Hermes runtime in-process. The bridge is an
explicitly configured service with its own Python/runtime and permission policy.
"""
from __future__ import annotations

import os
from typing import Any
from urllib.parse import urlparse

import httpx


class HermesNotConfigured(RuntimeError):
    pass


class HermesBridgeError(RuntimeError):
    pass


def _settings() -> tuple[str, str]:
    base_url = os.getenv("HERMES_ADAPTER_URL", "").strip().rstrip("/")
    token = os.getenv("HERMES_ADAPTER_TOKEN", "").strip()
    if not base_url or not token:
        raise HermesNotConfigured("Hermes bridge is not configured")
    parsed = urlparse(base_url)
    local_http = parsed.hostname in {"127.0.0.1", "localhost", "::1"} and parsed.scheme == "http"
    if parsed.scheme != "https" and not local_http:
        raise HermesNotConfigured("Hermes bridge must use HTTPS (HTTP is allowed only for localhost)")
    if not parsed.netloc or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise HermesNotConfigured("Hermes bridge URL is invalid")
    return base_url, token


def status() -> dict[str, Any]:
    try:
        base_url, token = _settings()
    except HermesNotConfigured:
        return {"configured": False, "reachable": False, "mode": "disabled"}
    try:
        with httpx.Client(timeout=httpx.Timeout(3.0, connect=1.5), follow_redirects=False) as client:
            response = client.get(f"{base_url}/health", headers={"Authorization": f"Bearer {token}"})
            response.raise_for_status()
            data = response.json()
            return {
                "configured": True,
                "reachable": True,
                "mode": "handoff-only",
                "bridge_status": str(data.get("status", "unknown"))[:80],
            }
    except (httpx.HTTPError, ValueError):
        return {"configured": True, "reachable": False, "mode": "handoff-only"}


def submit_handoff(task: dict[str, Any]) -> dict[str, Any]:
    """Submit only a reviewed handoff envelope; never forwards secrets or credentials."""
    base_url, token = _settings()
    envelope = {
        "task_id": str(task["id"]),
        "request": str(task["text"])[:10000],
        "model_tier": str(task.get("model_tier", "standard"))[:40],
        "mode": "handoff_only",
        "requires_remote_approval": True,
        "allowed_actions": ["READ_FILE", "LIST_FILES", "RUN_TESTS", "RUN_BUILD", "LINT", "FORMAT"],
    }
    try:
        with httpx.Client(timeout=httpx.Timeout(10.0, connect=2.0), follow_redirects=False) as client:
            response = client.post(
                f"{base_url}/tasks",
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                json=envelope,
            )
            response.raise_for_status()
            data = response.json()
    except (httpx.HTTPError, ValueError) as exc:
        raise HermesBridgeError("Hermes bridge request failed") from exc
    if not isinstance(data, dict) or data.get("accepted") is not True:
        raise HermesBridgeError("Hermes bridge did not confirm handoff acceptance")
    remote_id = data.get("job_id")
    if remote_id is not None and (not isinstance(remote_id, str) or len(remote_id) > 200):
        raise HermesBridgeError("Hermes bridge returned an invalid job identifier")
    return {"accepted": True, "job_id": remote_id, "mode": "handoff_only"}
