"""Opt-in OpenAI-compatible text-model adapter for GIA agent profiles.

This adapter intentionally does not read or retrieve personal RAG/memory data.
Only the explicit prompt supplied by an authenticated caller is sent to the configured provider.
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

from app.agents.registry import AGENTS


@dataclass(frozen=True)
class ProviderConfig:
    enabled: bool
    base_url: str
    model: str
    api_key: str
    timeout_seconds: float = 30.0


def get_config() -> ProviderConfig:
    raw_enabled = os.getenv("GIA_AGENT_PROVIDER_ENABLED", "").strip().lower()
    return ProviderConfig(
        enabled=raw_enabled in {"1", "true", "yes", "on"},
        base_url=os.getenv("GIA_AGENT_BASE_URL", "").strip().rstrip("/"),
        model=os.getenv("GIA_AGENT_MODEL", "").strip(),
        api_key=os.getenv("GIA_AGENT_API_KEY", "").strip(),
    )


def config_problem(config: ProviderConfig) -> str | None:
    if not config.enabled:
        return "provider_disabled"
    if not config.base_url or not config.model or not config.api_key:
        return "provider_configuration_incomplete"
    parsed = urlparse(config.base_url)
    if parsed.scheme != "https" and parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
        return "base_url_must_use_https_or_loopback"
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return "invalid_base_url"
    return None


def runtime_status() -> dict[str, Any]:
    config = get_config()
    problem = config_problem(config)
    return {
        "provider": "openai-compatible",
        "enabled": config.enabled,
        "configured": problem is None,
        "model": config.model or None,
        "agent_ids": [a.id for a in AGENTS],
        "ready_for_live_calls": problem is None,
        "reason": problem,
        "personal_memory_attached": False,
        "tool_execution_enabled": False,
    }


def invoke(agent_id: str, prompt: str) -> dict[str, Any]:
    """Send one explicit prompt to the configured model; no tools or memory are attached."""
    from app.agents.registry import agent_registry

    canonical = agent_registry.canonical_id(agent_id)
    if canonical is None:
        raise ValueError("Unknown agent ID")
    if not isinstance(prompt, str) or not prompt.strip() or len(prompt) > 12000:
        raise ValueError("Prompt must contain 1-12000 characters")
    config = get_config()
    problem = config_problem(config)
    if problem:
        raise RuntimeError(problem)

    agent = agent_registry.get(canonical)
    body = {
        "model": config.model,
        "messages": [
            {"role": "system", "content": f"You are the GIA {agent['role']} agent. Respond to the supplied task only. You have no tools and no retrieved personal memory in this call."},
            {"role": "user", "content": prompt.strip()},
        ],
        "stream": False,
    }
    request = urllib.request.Request(
        config.base_url + "/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers={"Authorization": "Bearer " + config.api_key,
                 "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=config.timeout_seconds) as response:
            result = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"provider_http_error_{exc.code}") from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise RuntimeError("provider_connection_failed") from None
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise RuntimeError("provider_invalid_response") from None

    try:
        content = result["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        raise RuntimeError("provider_response_missing_content") from None
    if not isinstance(content, str):
        raise RuntimeError("provider_response_missing_content")
    return {"agent_id": canonical, "provider": "openai-compatible",
            "model": config.model, "status": "COMPLETED", "output": content,
            "personal_memory_attached": False, "tools_invoked": []}
