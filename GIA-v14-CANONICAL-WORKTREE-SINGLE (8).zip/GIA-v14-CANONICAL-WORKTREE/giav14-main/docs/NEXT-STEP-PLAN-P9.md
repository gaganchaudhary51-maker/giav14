# Next Step Plan — P9 Final Validation & Live Introduction

## Goal
Prepare GIA for one honest, guided live introduction and a single final user acceptance pass. Do not call the product Ready to Use until the release gates below have evidence.

## Workstreams

### 1. Release verification (blocking)
- Install the exact frontend dependencies from `frontend/package-lock.json` on the target Windows environment using `npm ci`.
- Run `npm run build`; save the full console output and exit code.
- Run the backend verification script and retain its timestamped report.
- Start the API and frontend, then test signup, login, project creation/selection, plan creation, Knowledge indexing/search/version history, Memory save/search, activity refresh, and Settings status.
- Test SQLite backup and restore using a disposable copy of the database.
- Validate production configuration: `GIA_ENV=production`, unique `GIA_AUTH_SECRET` (32+ random characters), HTTPS at deployment, no secrets in source control.

### 2. Integration verification (blocking if enabled for release)
- Keep Hermes integration disabled unless a trusted bridge URL and token are explicitly configured.
- Test authenticated bridge health and one harmless, allowlisted handoff against a running Hermes service.
- Confirm approval, sandbox, tool allowlist, timeout/cancellation, and audit behavior on the bridge side.
- If no live bridge is available, document Hermes as optional/unavailable in the release UI; do not present it as connected.
- Verify HRGen-inspired RAG/memory behavior using fixture documents. GIA currently uses lexical/offline-friendly retrieval; semantic embeddings are not active.

### 3. Live introduction content
- First-run screen explains the product in plain language.
- The intro distinguishes a proposed plan from an executed task.
- It explains the user journey: choose a project, describe a goal, review the plan, verify the outcome.
- It avoids unsupported claims about autonomy, accuracy, privacy guarantees, external integrations, or production readiness.
- The demo uses synthetic/sample information only and never displays real credentials or private user documents.

### 4. User acceptance
- Give the user one consolidated test session after the blocking gates pass.
- Capture issues as reproducible items with expected/actual behavior and severity.
- Fix release-blocking issues before producing the final package.
- Create one final source ZIP and one library ZIP; include reports, setup/verification guide, known limitations, and a manifest. Exclude `.env`, secrets, databases, caches, virtual environments, and `node_modules`.

## Acceptance criteria
- [ ] Windows frontend production build succeeds.
- [ ] Backend suite passes from a clean extraction.
- [ ] Browser smoke flows pass.
- [ ] SQLite backup/restore passes.
- [ ] Hermes live handoff passes OR Hermes is explicitly marked optional and disconnected.
- [ ] RAG/memory fixtures pass and project/user isolation is verified.
- [ ] Introductory copy and demo use only verified capabilities.
- [ ] Final readiness report lists every check as PASS, FAIL, or NOT RUN with evidence.

## Current status
The current workspace evidence says backend tests and source packaging checks passed in the prior verification run. Frontend production build, browser end-to-end checks, database backup/restore, and a live Hermes handoff remain unverified. Therefore the current package is a candidate, not a certified Ready-to-Use release.
