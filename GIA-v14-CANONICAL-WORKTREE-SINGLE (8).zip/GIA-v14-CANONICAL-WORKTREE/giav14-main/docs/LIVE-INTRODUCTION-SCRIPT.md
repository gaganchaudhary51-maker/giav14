# GIA Live Introduction — Presenter Script

**Target length:** 3–4 minutes  
**Audience:** first-time user  
**Demo data:** use only a disposable demo account and fictional project/content.

## Opening (20 seconds)
“Welcome to GIA, your AI workspace for keeping projects, plans, knowledge, and memory together. The focus is visibility: you should be able to tell what GIA proposed, what actually ran, and what still needs your approval.”

## Tour (45 seconds)
“Start with Projects. Create or select one project so work has a clear home. Agents shows the available agent capabilities and status. Knowledge is where you can index text and search it later. Memory lets you save useful notes with tags and importance. Settings shows system and integration status.”

## Safe first task (60 seconds)
“I’ll ask GIA to plan a small, harmless task—for example, organize a fictional launch checklist. A plan is a proposal, not proof that the task was executed. Review the steps and the activity record before treating any outcome as complete.”

## Knowledge and memory (45 seconds)
“I’ll add a short fictional note to Knowledge, search for a phrase from it, and then save a separate memory note. Search results should be relevant to the selected project. The demo uses sample text only; do not paste secrets or confidential records into a demo.”

## Integrations and boundaries (30 seconds)
“External integrations such as Hermes only work when a trusted service is configured and verified. If the status says disconnected or unavailable, that is the honest state. GIA’s current retrieval is lexical/offline-friendly; semantic embedding search is not active unless a future release explicitly enables and tests it.”

## Close (20 seconds)
“That’s the basic flow: choose a project, describe a goal, review the plan, add/search knowledge, save/retrieve memory, and verify status. Today’s release status and known limitations are documented in the readiness report.”

## Presenter checklist
- [ ] Use a fresh demo account and fictional data.
- [ ] Confirm API and frontend are both running.
- [ ] Confirm the visible system status before presenting.
- [ ] Do not claim a task executed merely because a plan was returned.
- [ ] Do not claim Hermes is live unless the live handoff check passed.
- [ ] Do not claim production readiness until every blocking release gate has evidence.
