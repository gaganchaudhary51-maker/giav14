# Hermes Bridge Contract

GIA v14 integrates Hermes through a separate trusted bridge service, not by importing the Hermes repository into the FastAPI process.

## Configure GIA
Set these environment variables on the GIA backend. Keep the token secret and do not commit it.

- `HERMES_ADAPTER_URL`: base URL of the bridge. Must use HTTPS except for localhost development.
- `HERMES_ADAPTER_TOKEN`: bearer token shared with the bridge.

Leave both unset to keep the integration disabled.

## Endpoints expected on the bridge

### `GET /health`
Authenticated with `Authorization: Bearer <token>`. Return a JSON object with a simple `status` field (for example, `{"status":"ok"}`).

### `POST /tasks`
Authenticated with the same bearer token. Accepts a minimal envelope:

- `task_id`: GIA task ID
- `request`: user task text
- `model_tier`: GIA's selected tier
- `mode`: always `handoff_only`
- `requires_remote_approval`: always `true`
- `allowed_actions`: restricted list of read/list/test/build/lint/format actions

Return `{"accepted": true, "job_id": "..."}` only after the bridge durably accepts the handoff. If the bridge does not confirm acceptance, GIA treats it as a failed handoff.

## Mandatory behavior for a compatible bridge
- Treat the handoff as a request, not authorization to execute.
- Require a second explicit approval in the Hermes environment before tool execution.
- Enforce tool allowlists, user/session isolation, cancellation, resource limits, and audit logging independently.
- Never return secrets or credentials in the response.
- Do not follow arbitrary callback URLs supplied in the payload.
- Use TLS, rotate credentials, and rate-limit the endpoint.

## Current scope
GIA's bridge client and API routes are implemented and unit-tested. A live Hermes bridge is not included or auto-started by this source package. The upstream Hermes project declares Python `<3.14`, so keep it isolated in a supported runtime such as Python 3.13 until upstream compatibility changes.
