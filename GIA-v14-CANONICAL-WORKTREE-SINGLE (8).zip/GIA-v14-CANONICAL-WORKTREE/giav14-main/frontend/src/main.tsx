import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { api } from "./api";
import "./styles.css";

type Project = { id: string; name: string; description?: string; status?: string };
type EventItem = { type?: string; event_type?: string; payload?: unknown };
type Agent = { id?: string; name?: string; role?: string; description?: string; capabilities?: string[] };
type StudioPod = { id: string; name: string; role: string; description: string; prompt: string; model: string; models: string[]; channels: string[]; enabled: boolean; updated_at?: string };
type Section = "Home" | "Projects" | "Agents" | "Studio" | "Knowledge" | "Memory" | "Settings";
type SpeechRecognitionLike = any;

const nav: { icon: string; label: Section }[] = [
  { icon: "⌂", label: "Home" },
  { icon: "▣", label: "Projects" },
  { icon: "◈", label: "Agents" },
  { icon: "◌", label: "Knowledge" },
  { icon: "✧", label: "Memory" },
  { icon: "⚙", label: "Settings" },
];

function App() {
  const [introComplete, setIntroComplete] = useState(localStorage.getItem("gia_intro_complete") === "yes");
  const [user, setUser] = useState<any>();
  const [projects, setProjects] = useState<Project[]>([]);
  const [selected, setSelected] = useState("");
  const [input, setInput] = useState("");
  const [activity, setActivity] = useState<EventItem[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [section, setSection] = useState<Section>(() => window.location.pathname === "/studio" ? "Studio" : "Home");
  const [menu, setMenu] = useState(false);
  const [voice, setVoice] = useState(false);
  const [voiceError, setVoiceError] = useState("");
  const [voiceSession, setVoiceSession] = useState("");
  const [lastResult, setLastResult] = useState<any>();
  const [agents, setAgents] = useState<Agent[]>([]);
  const [studioPods, setStudioPods] = useState<StudioPod[]>([]);
  const [studioPodId, setStudioPodId] = useState("");
  const [studioModel, setStudioModel] = useState("Puck");
  const [studioPrompt, setStudioPrompt] = useState("");
  const [studioChannels, setStudioChannels] = useState<string[]>(["Web Chat"]);
  const [studioEnabled, setStudioEnabled] = useState(true);
  const [studioEvolution, setStudioEvolution] = useState<any>();
  const [studioMetrics, setStudioMetrics] = useState({ failure: "", missed: "", bottleneck: "", aht: "0" });
  const [studioTranscript, setStudioTranscript] = useState<any[]>([]);
  const [studioRunPrompt, setStudioRunPrompt] = useState("");
  const [studioRunResult, setStudioRunResult] = useState<any>();
  const [studioRunBusy, setStudioRunBusy] = useState(false);
  const [studioDemoNote, setStudioDemoNote] = useState("Demo mode · no live telephony or customer records connected");
  const [systemStatus, setSystemStatus] = useState<any>();
  const [hermesStatus, setHermesStatus] = useState<any>();
  const [ragSource, setRagSource] = useState("");
  const [ragText, setRagText] = useState("");
  const [ragTags, setRagTags] = useState("");
  const [ragQuery, setRagQuery] = useState("");
  const [ragResults, setRagResults] = useState<any[]>([]);
  const [ragDocuments, setRagDocuments] = useState<any[]>([]);
  const [ragHistory, setRagHistory] = useState<any[]>([]);
  const [memoryText, setMemoryText] = useState("");
  const [memoryTags, setMemoryTags] = useState("");
  const [memoryImportance, setMemoryImportance] = useState(3);
  const [memoryQuery, setMemoryQuery] = useState("");
  const [memoryResults, setMemoryResults] = useState<any[]>([]);
  const recognitionRef = useRef<SpeechRecognitionLike>(null);

  const activeProject = projects.find((project) => project.id === selected);

  async function refresh() {
    try {
      const current = await api.me();
      setUser(current);
      const [projectList, eventData] = await Promise.all([api.projects(), api.events()]);
      setProjects(projectList);
      setActivity(eventData.events || []);
    } catch {
      localStorage.removeItem("gia_token");
      setUser(undefined);
    }
  }

  useEffect(() => { void refresh(); }, []);
  useEffect(() => {
    const onPopState = () => setSection(window.location.pathname === "/studio" ? "Studio" : "Home");
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);
  useEffect(() => {
    if (section === "Studio" && user) void loadStudio();
  }, [section, user]);
  useEffect(() => {
    if (!user || !selected) { setRagDocuments([]); return; }
    void api.ragDocuments(selected).then((result) => setRagDocuments(result.documents || [])).catch(() => setRagDocuments([]));
  }, [user, selected]);

  useEffect(() => {
    if (!user) return;
    const timer = window.setInterval(async () => {
      try { setActivity((await api.events()).events || []); } catch { /* keep last known events */ }
    }, 5000);
    return () => window.clearInterval(timer);
  }, [user]);

  function finishIntro() {
    localStorage.setItem("gia_intro_complete", "yes");
    setIntroComplete(true);
  }

  async function auth(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    try {
      const result = mode === "login"
        ? await api.login(email, password)
        : await api.signup(name, email, password);
      localStorage.setItem("gia_token", result.token);
      await refresh();
    } catch (caught: any) {
      setError(caught.message || "Sign-in failed. Check the API server and your details.");
    }
  }

  async function createProject() {
    const projectName = window.prompt("Project name");
    if (!projectName?.trim()) return;
    setBusy(true);
    setError("");
    try {
      const project = await api.createProject(projectName.trim(), "");
      setProjects((items) => [project, ...items]);
      setSelected(project.id);
      setSection("Projects");
      setNotice("Project created.");
    } catch (caught: any) {
      setError(caught.message);
    } finally { setBusy(false); }
  }

  async function submitPlan(override?: string) {
    const text = (override ?? input).trim();
    if (!text || busy) return;
    if (!selected) {
      setError("Create or select a project first so the work has a clear home.");
      setSection("Projects");
      return;
    }
    setInput("");
    setBusy(true);
    setError("");
    setNotice("");
    try {
      // This endpoint creates a plan only; it does not claim to execute the task.
      const result = await api.plan(text, selected);
      setLastResult(result);
      setActivity((items) => [{ type: "GIA_PLAN_CREATED", payload: result }, ...items]);
      if (voice) speak(typeof result.summary === "string" ? result.summary : "Plan created. Review the proposed next steps.");
    } catch (caught: any) {
      setError(caught.message);
    } finally { setBusy(false); }
  }

  function speak(text: string) {
    if (!("speechSynthesis" in window) || !text) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.slice(0, 1200));
    utterance.lang = "en-IN";
    utterance.onstart = () => { if (voiceSession) void api.voiceState(voiceSession, "SPEAKING").catch(() => {}); };
    utterance.onend = () => { if (voiceSession) void api.voiceState(voiceSession, "IDLE").catch(() => {}); };
    window.speechSynthesis.speak(utterance);
  }

  async function stopVoice() {
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch { /* already stopped */ }
      recognitionRef.current = null;
    }
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    if (voiceSession) await api.voiceState(voiceSession, "IDLE").catch(() => {});
    setVoice(false);
    setVoiceSession("");
  }

  async function startVoice() {
    setVoiceError("");
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setVoiceError("Speech recognition is not supported by this browser. You can type your request instead.");
      return;
    }
    try {
      const session = await api.voiceStart(selected || undefined);
      setVoiceSession(session.id);
      await api.voiceState(session.id, "LISTENING");
      const recognition = new SpeechRecognition();
      recognition.lang = "en-IN";
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.onresult = async (event: any) => {
        const transcript = Array.from(event.results).map((item: any) => item[0]?.transcript || "").join(" ").trim();
        if (!transcript) return;
        setInput(transcript);
        try { await api.voiceTranscript(session.id, transcript); await submitPlan(transcript); }
        catch (caught: any) { setVoiceError(caught.message); }
      };
      recognition.onerror = (event: any) => { setVoiceError(event.error || "Speech recognition failed"); setVoice(false); };
      recognition.onend = () => { recognitionRef.current = null; setVoice(false); };
      recognitionRef.current = recognition;
      recognition.start();
      setVoice(true);
    } catch (caught: any) {
      setVoiceError(caught.message || "Could not start voice session");
      setVoice(false);
    }
  }

  async function loadStudio() {
    setBusy(true); setError("");
    try {
      const result = await api.studioPods();
      const pods = result.pods || [];
      setStudioPods(pods);
      const chosen = pods.find((pod: StudioPod) => pod.id === studioPodId) || pods[0];
      if (chosen) {
        setStudioPodId(chosen.id); setStudioPrompt(chosen.prompt); setStudioModel(chosen.model);
        setStudioChannels(chosen.channels || []); setStudioEnabled(Boolean(chosen.enabled));
      }
      const demo = await api.studioCallCenterDemo();
      setStudioTranscript(demo.transcript || []); setStudioDemoNote(demo.note || "Demo mode");
    } catch (caught: any) { setError(caught.message || "Could not load Studio configuration."); }
    finally { setBusy(false); }
  }

  function selectStudioPod(id: string) {
    const pod = studioPods.find((item) => item.id === id);
    if (!pod) return;
    setStudioPodId(id); setStudioPrompt(pod.prompt); setStudioModel(pod.model);
    setStudioChannels(pod.channels || []); setStudioEnabled(Boolean(pod.enabled)); setStudioEvolution(undefined);
  }

  async function saveStudioPod(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const result = await api.studioUpdatePod(studioPodId, { prompt: studioPrompt, model: studioModel, channels: studioChannels, enabled: studioEnabled });
      setStudioPods((items) => items.map((pod) => pod.id === studioPodId ? result.pod : pod));
      setNotice("Studio pod configuration saved for this signed-in tenant. No live call was initiated.");
    } catch (caught: any) { setError(caught.message || "Could not save pod configuration."); }
    finally { setBusy(false); }
  }

  async function proposeStudioEvolution(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setStudioEvolution(undefined);
    try {
      const result = await api.studioEvolve({ pod_id: studioPodId,
        failure_logs: studioMetrics.failure ? [studioMetrics.failure] : [],
        missed_prompts: studioMetrics.missed ? [studioMetrics.missed] : [],
        bottlenecks: studioMetrics.bottleneck ? [studioMetrics.bottleneck] : [],
        aht_seconds: Number(studioMetrics.aht || 0) });
      setStudioEvolution(result);
      setNotice("Evolution proposal generated. Active prompt remains unchanged until you approve it.");
    } catch (caught: any) { setError(caught.message || "Evolution provider is not configured."); }
    finally { setBusy(false); }
  }

  async function reviewStudioEvolution(approve: boolean) {
    if (!studioEvolution?.proposal_id) return;
    setBusy(true); setError("");
    try {
      const result = await api.studioReviewEvolution(studioEvolution.proposal_id, approve);
      setNotice(approve ? "Reviewed prompt proposal applied." : "Prompt proposal rejected; active prompt unchanged.");
      setStudioEvolution(undefined);
      if (approve) await loadStudio();
    } catch (caught: any) { setError(caught.message || "Could not review evolution proposal."); }
    finally { setBusy(false); }
  }

  async function loadAgents() {
    setBusy(true); setError("");
    try { setAgents((await api.agents()).agents || []); }
    catch (caught: any) { setError(caught.message); }
    finally { setBusy(false); }
  }

  async function runSelectedStudioPod(event: React.FormEvent) {
    event.preventDefault();
    const taskText = studioRunPrompt.trim();
    const pod = studioPods.find((item) => item.id === studioPodId);
    if (!taskText || !pod || !selected) {
      setError(!selected ? "Select a project before running an agent." : "Choose a pod and enter a task.");
      return;
    }
    if (!pod.enabled) { setError("This pod is paused. Enable it before running."); return; }
    setStudioRunBusy(true); setError(""); setNotice(""); setStudioRunResult(undefined);
    let task: any;
    try {
      task = await api.createTask(taskText);
      if (task.status === "APPROVAL_REQUIRED") {
        setStudioRunResult({ status: "APPROVAL_REQUIRED", task_id: task.id, requested_count: 0, completed_count: 0, results: [] });
        setNotice("This task requires approval before execution. It has not been run.");
        return;
      }
      await api.updateTaskStatus(task.id, "EXECUTING");
      const podToAgent: Record<string, string> = {
        "ritu-reception": "voice", "rahul-sales": "planner", "sophia-whatsapp": "backend",
        "lucas-growth": "research", "swarn-auditor": "analytics", "boat-commerce": "backend",
        "social-marketing": "research", "google-web": "research", "branding-agent": "ui",
        "graphic-designer": "ui"
      };
      const result = await api.runAgentTeam(task.id, [podToAgent[pod.id] || "planner"], `${pod.prompt}\n\nUSER TASK:\n${taskText}`);
      setStudioRunResult(result);
      await api.updateTaskStatus(task.id, result.completed_count > 0 ? "EXECUTED" : "FAILED");
      setNotice(result.status === "COMPLETED" ? "Agent execution completed and task status updated." : `Agent execution status: ${result.status}. Check the result details.`);
      setActivity((items) => [{ type: "STUDIO_AGENT_RUN", payload: result }, ...items]);
    } catch (caught: any) {
      setError(caught.message || "Agent run failed. Check provider configuration and task status.");
      if (task?.id) {
        try { await api.updateTaskStatus(task.id, "FAILED"); } catch { /* preserve original error */ }
      }
    } finally { setStudioRunBusy(false); }
  }

  async function loadSystemStatus() {
    setBusy(true); setError("");
    try {
      const [health, persistence] = await Promise.all([api.health(), api.persistence()]);
      setSystemStatus({ health, persistence });
    } catch (caught: any) { setError(caught.message); }
    finally { setBusy(false); }
  }

  async function loadHermesStatus() {
    setBusy(true); setError("");
    try { setHermesStatus(await api.hermesStatus()); }
    catch (caught: any) { setError(caught.message); }
    finally { setBusy(false); }
  }

  async function indexKnowledge(event: React.FormEvent) {
    event.preventDefault();
    if (!selected) { setError("Select a project before indexing knowledge."); return; }
    setBusy(true); setError(""); setNotice("");
    try {
      const tags = ragTags.split(",").map((tag) => tag.trim()).filter(Boolean).slice(0, 20);
      const result = await api.ragIndex(selected, ragSource.trim(), ragText.trim(), tags);
      setNotice(`Indexed ${result.indexed} chunks from ${result.source}. Previous versions are retained.`);
      setRagText("");
      setRagDocuments((await api.ragDocuments(selected)).documents || []);
    } catch (caught: any) { setError(caught.message); }
    finally { setBusy(false); }
  }

  async function loadRagHistory(source: string) {
    if (!selected) return;
    try { setRagHistory((await api.ragHistory(selected, source)).versions || []); }
    catch (caught: any) { setError(caught.message); }
  }

  async function searchKnowledge(event: React.FormEvent) {
    event.preventDefault();
    if (!selected) { setError("Select a project before searching knowledge."); return; }
    setBusy(true); setError("");
    try { setRagResults((await api.ragSearch(selected, ragQuery.trim())).items || []); }
    catch (caught: any) { setError(caught.message); }
    finally { setBusy(false); }
  }

  async function saveMemory(event: React.FormEvent) {
    event.preventDefault();
    if (!selected) { setError("Select a project before saving a memory."); return; }
    setBusy(true); setError(""); setNotice("");
    try {
      const tags = memoryTags.split(",").map((tag) => tag.trim()).filter(Boolean).slice(0, 20);
      await api.memoryAdd(selected, "personal-note", memoryText.trim(), tags, memoryImportance);
      setNotice("Memory saved to durable project storage.");
      setMemoryText("");
    } catch (caught: any) { setError(caught.message); }
    finally { setBusy(false); }
  }

  async function searchMemory(event: React.FormEvent) {
    event.preventDefault();
    if (!selected) { setError("Select a project before searching memory."); return; }
    setBusy(true); setError("");
    try { setMemoryResults((await api.memorySearch(selected, memoryQuery.trim())).items || []); }
    catch (caught: any) { setError(caught.message); }
    finally { setBusy(false); }
  }

  if (!introComplete) {
    return <div className="intro-screen">
      <div className="intro-orb">G</div>
      <div className="eyebrow">GIA · UNIVERSAL AI WORKSPACE</div>
      <h1>Plan clearly. Keep work in view.</h1>
      <p className="intro-lede">GIA brings projects, plan review, searchable knowledge and project memory into one focused workspace. It makes the difference between a proposed plan and a verified result visible.</p>
      <div className="intro-steps">
        <div><span>01</span><b>Choose a project</b><small>Keep related tasks and knowledge in one place.</small></div>
        <div><span>02</span><b>Describe and review</b><small>GIA prepares a plan; a plan alone does not mean the task was executed.</small></div>
        <div><span>03</span><b>Verify the result</b><small>Use activity and system status to distinguish real results from plans.</small></div>
      </div>
      <div className="intro-privacy"><span>◈</span><p><b>Know what is connected.</b> Project knowledge and memory use project-scoped storage. External integrations such as Hermes must be configured and verified separately; demo with sample data, not secrets.</p></div>
      <button className="primary intro-continue" onClick={finishIntro}>Continue to sign in <span>→</span></button>
      <small className="intro-foot">A short introduction shown once per browser. You can reopen it from the sign-in screen.</small>
    </div>;
  }

  if (!user) {
    return <div className="auth">
      <form onSubmit={auth}>
        <div className="brand auth-brand"><div className="orb">G</div><div><b>GIA</b><small>Universal Commander</small></div></div>
        <div className="eyebrow">YOUR WORKSPACE STARTS HERE</div>
        <h1>{mode === "login" ? "Welcome back." : "Create your account."}</h1>
        <p>Sign in to access your projects, agent plans, knowledge and memory.</p>
        {mode === "signup" && <label>Name<input autoComplete="name" placeholder="Your name" value={name} onChange={(event) => setName(event.target.value)} required /></label>}
        <label>Email<input autoComplete="email" placeholder="you@example.com" type="email" value={email} onChange={(event) => setEmail(event.target.value)} required /></label>
        <label>Password<input autoComplete={mode === "login" ? "current-password" : "new-password"} placeholder="At least 8 characters" type="password" minLength={mode === "signup" ? 8 : 1} value={password} onChange={(event) => setPassword(event.target.value)} required /></label>
        <button className="primary wide" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Sign in to GIA" : "Create account"}</button>
        {error && <div className="error" role="alert">{error}</div>}
        <button type="button" className="link" onClick={() => { setError(""); setMode(mode === "login" ? "signup" : "login"); }}>{mode === "login" ? "New to GIA? Create an account" : "Already have an account? Sign in"}</button>
        <button type="button" className="link subtle-link" onClick={() => { localStorage.removeItem("gia_intro_complete"); setIntroComplete(false); }}>View introduction again</button>
      </form>
    </div>;
  }

  return <div className="app">
    <aside className={`side ${menu ? "open" : ""}`}>
      <div className="brand"><div className="orb">G</div><div><b>GIA</b><small>Universal Commander</small></div></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{nav.map((item) => <button className={section === item.label ? "sel" : ""} onClick={() => { setSection(item.label); window.history.pushState({}, "", item.label === "Studio" ? "/studio" : "/"); setMenu(false); setError(""); setNotice(""); if (item.label === "Agents") void loadAgents(); if (item.label === "Settings") void loadSystemStatus(); }} key={item.label}><i>{item.icon}</i>{item.label}</button>)}</nav>
      <div className="side-project">
        <small>ACTIVE PROJECT</small>
        <select aria-label="Active project" value={selected} onChange={(event) => setSelected(event.target.value)}>
          <option value="">Select a project</option>
          {projects.map((project) => <option value={project.id} key={project.id}>{project.name}</option>)}
        </select>
        <button className="new-project" onClick={() => void createProject()}>＋ New project</button>
      </div>
      <div className="bottom"><span className="online">● API session active</span><button className="profile" onClick={() => { localStorage.removeItem("gia_token"); setUser(undefined); }}>{user.name} · {user.role || "User"} <span>Sign out</span></button></div>
    </aside>

    <main className="main-area">
      <header className="topbar">
        <button className="hamb" onClick={() => setMenu(!menu)} aria-label="Toggle navigation">☰</button>
        <div><b>{activeProject?.name || "GIA Workspace"}</b><span className="crumb"> / {section}</span></div>
        <span className="live"><i /> CONNECTED</span>
      </header>

      {error && <div className="global-message error-message" role="alert"><span>!</span>{error}<button onClick={() => setError("")} aria-label="Dismiss error">×</button></div>}
      {notice && <div className="global-message success-message" role="status"><span>✓</span>{notice}<button onClick={() => setNotice("")} aria-label="Dismiss notice">×</button></div>}

      {section === "Home" && <section className="page home">
        <div className="eyebrow">COMMAND CENTER / OVERVIEW</div>
        <h1>Good to see you,<br /><em>let’s make progress.</em></h1>
        <p className="page-lede">Describe the outcome you want. GIA can prepare a governed plan; review its status and evidence before treating work as complete.</p>
        <div className={`composer ${voice ? "listen" : ""}`}>
          <textarea value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void submitPlan(); } }} placeholder={selected ? "Describe a goal, question or task…" : "Select or create a project first…"} aria-label="Describe a task" />
          <div className="composer-footer">
            <div className="suggestions"><button onClick={() => setInput("Explain the current project architecture")}>Explain project</button><button onClick={() => setInput("Plan a full test and verification pass")}>Test & verify</button></div>
            <div className="composer-actions"><button className={voice ? "voice on" : "voice"} onClick={() => voice ? void stopVoice() : void startVoice()}>{voice ? "◉ Listening" : "◉ Voice"}</button><button className="primary run" disabled={busy} onClick={() => void submitPlan()}>{busy ? "Preparing…" : "Create plan →"}</button></div>
          </div>
          {voiceError && <div className="inline-warning">{voiceError}</div>}
        </div>
        {lastResult && <div className="result-card"><div className="result-title"><span className="status-dot" />Latest plan <span className="pill">{lastResult.status || "planned"}</span></div><p>{lastResult.intent || "Plan created."}</p><div className="result-grid"><div><small>MODEL TIER</small><b>{lastResult.model_tier || "Not specified"}</b></div><div><small>APPROVAL</small><b>{lastResult.approval_required ? "Required" : "Not flagged"}</b></div><div><small>TASK ID</small><b>{lastResult.task_id || "—"}</b></div></div><small className="muted">A plan is not proof of execution. Use task/execution verification before marking work complete.</small></div>}
        <div className="section-heading"><div><div className="eyebrow">YOUR WORK</div><h2>Projects</h2></div><button className="secondary" onClick={() => void createProject()}>＋ New project</button></div>
        <div className="project-grid">{projects.slice(0, 6).map((project) => <button className={`project-card ${selected === project.id ? "selected" : ""}`} onClick={() => setSelected(project.id)} key={project.id}><span className="project-icon">◈</span><span className="project-copy"><b>{project.name}</b><small>{project.description || "Project workspace"}</small><em>{project.status || "ACTIVE"}</em></span><span className="arrow">↗</span></button>)}{!projects.length && <div className="empty-card"><b>No projects yet</b><p>Create your first project to give tasks, knowledge and memories a clear home.</p><button className="secondary" onClick={() => void createProject()}>Create first project</button></div>}</div>
      </section>}

      {section === "Projects" && <section className="page">
        <div className="eyebrow">WORKSPACES</div><h1 className="page-title">Projects</h1><p className="page-lede">Keep related goals, knowledge and memories together. Select one project to scope your next action.</p>
        <button className="primary" onClick={() => void createProject()}>＋ Create project</button>
        <div className="project-grid full-grid">{projects.map((project) => <button className={`project-card ${selected === project.id ? "selected" : ""}`} onClick={() => setSelected(project.id)} key={project.id}><span className="project-icon">◈</span><span className="project-copy"><b>{project.name}</b><small>{project.description || "Project workspace"}</small><em>{selected === project.id ? "SELECTED" : project.status || "ACTIVE"}</em></span><span className="arrow">↗</span></button>)}</div>
      </section>}

      {section === "Agents" && <section className="page">
        <div className="eyebrow">ORCHESTRATION</div><h1 className="page-title">Agents</h1><p className="page-lede">Inspect the agent registry exposed by the current GIA API. Registry presence does not mean a live tool run has happened.</p>
        <div className="toolbar"><button className="secondary" disabled={busy} onClick={() => void loadAgents()}>↻ Refresh agents</button><span className="muted">{agents.length} registered</span></div>
        <div className="agent-grid">{agents.map((agent, index) => <div className="agent-card" key={agent.id || agent.name || index}><span className="agent-avatar">◈</span><div><b>{agent.name || agent.role || agent.id || `Agent ${index + 1}`}</b><p>{agent.description || "Registered agent in the current GIA backend."}</p>{agent.capabilities?.length ? <div className="tag-list">{agent.capabilities.map((capability) => <span className="tag" key={capability}>{capability}</span>)}</div> : null}</div></div>)}{!agents.length && <div className="empty-card"><b>No agent data loaded</b><p>Refresh to query the authenticated backend registry.</p><button className="secondary" onClick={() => void loadAgents()}>Load agents</button></div>}</div>
      </section>}

      {section === "Studio" && <section className="studio-page">
        <div className="studio-heading"><div><div className="eyebrow">UNIVERSAL AGENT PODS · MULTI-CHANNEL</div><h1>Agent Studio</h1><p>Configure the ten requested pods, prompts, audio engine selection and channel availability. This controls configuration only; external telephony and messaging are not connected yet.</p></div><button className="studio-primary" disabled={busy} onClick={() => void loadStudio()}>Refresh pods</button></div>
        <form className="studio-execution-panel" onSubmit={runSelectedStudioPod}>
          <div><span className="studio-kicker">REAL AGENT EXECUTION</span><h2>Run selected pod</h2><p>Uses the signed-in account, selected project, task ownership checks and configured model provider. Provider-offline is shown as an error, never as a fake success.</p></div>
          <label>Task for this pod<textarea value={studioRunPrompt} onChange={(e) => setStudioRunPrompt(e.target.value)} placeholder="Describe the work this agent should perform…" rows={3} required /></label>
          <button className="studio-primary" disabled={studioRunBusy || busy || !selected || !studioPodId || !studioRunPrompt.trim()}>{studioRunBusy ? "Running agent…" : "▶ Run agent"}</button>
          {!selected && <small>Select a project from the sidebar before running.</small>}
          {studioRunResult && <div className="studio-run-result"><b>Run status: {studioRunResult.status}</b><small>Task: {studioRunResult.task_id} · Completed: {studioRunResult.completed_count}/{studioRunResult.requested_count}</small>{(studioRunResult.results || []).map((r: any, i: number) => <div key={`${r.agent_id}-${i}`}><b>{r.agent_id} — {r.status}</b><p>{r.output || r.error || "No output returned."}</p>{r.provider && <small>Provider: {r.provider} · Model: {r.model}</small>}</div>)}</div>}
        </form>
        <div className="studio-summary"><div><small>REGISTERED PODS</small><b>{studioPods.length || 10}</b><span>10 requested profiles</span></div><div><small>CHANNELS</small><b>3</b><span>Voice Call · WhatsApp · Web Chat</span></div><div><small>CONFIGURATION</small><b>Tenant scoped</b><span>Saved in local SQLite</span></div><div><small>TELEPHONY</small><b>Demo</b><span>Provider setup pending</span></div></div>
        <div className="studio-layout">
          <div className="studio-pod-list"><h2>Agent pods</h2>{studioPods.map((pod) => <button type="button" key={pod.id} className={`studio-pod-choice ${studioPodId === pod.id ? "active" : ""}`} onClick={() => selectStudioPod(pod.id)}><span className="studio-pod-avatar">{pod.name.split(" ").map((x) => x[0]).slice(0,2).join("")}</span><span><b>{pod.name}</b><small>{pod.role}</small><em>{pod.enabled ? "Active" : "Paused"} · {pod.model} · {(pod.channels || []).join(", ") || "No channels"}</em></span></button>)}</div>
          <form className="studio-editor" onSubmit={saveStudioPod}>
            {(() => { const pod = studioPods.find((item) => item.id === studioPodId); return <><div className="studio-editor-head"><div><span className="studio-kicker">POD CONFIGURATION</span><h2>{pod?.name || "Select an agent pod"}</h2><p>{pod?.description || "Choose a profile to edit its configuration."}</p></div><label className="studio-toggle"><input type="checkbox" checked={studioEnabled} onChange={(e) => setStudioEnabled(e.target.checked)} /> Enabled</label></div>
            <label>System prompt<textarea value={studioPrompt} onChange={(e) => setStudioPrompt(e.target.value)} rows={7} required maxLength={12000} /></label>
            <div className="studio-form-grid"><label>Audio engine<select value={studioModel} onChange={(e) => setStudioModel(e.target.value)}>{["Kore","Fenrir","Zephyr","Puck"].map((m) => <option key={m}>{m}</option>)}</select><small>Selection stored; engine runtime adapter not yet wired.</small></label><div><label>Available channels</label><div className="studio-channel-options">{["Voice Call","WhatsApp","Web Chat"].map((channel) => <label key={channel}><input type="checkbox" checked={studioChannels.includes(channel)} onChange={(e) => setStudioChannels((xs) => e.target.checked ? [...xs, channel] : xs.filter((x) => x !== channel))} /> {channel}</label>)}</div></div></div>
            <div className="studio-footer"><span>Tenant-scoped config · Existing personal RAG/memory untouched</span><button className="studio-primary" disabled={busy || !studioPodId}>Save configuration</button></div></>; })()}
          </form>
        </div>
        <div className="studio-call-center"><div className="studio-call-title"><div><span className="studio-kicker">CALL CENTER</span><h2>Real-time operations HUD</h2></div><span className="studio-demo-status">Demo data · not a live call</span></div>
          <div className="studio-split"><div className="studio-pane"><h3>Live transcript feed</h3><div className="studio-transcript">{studioTranscript.map((line: any, i: number) => <div key={i} className="studio-transcript-line"><time>{line.time}</time><div><b>{line.speaker}</b><p>{line.text}</p></div></div>)}<p className="studio-demo-note">{studioDemoNote}</p></div></div>
          <div className="studio-pane"><h3>Customer context & next actions</h3><div className="studio-context-card"><small>CUSTOMER HISTORY</small><p>No customer records connected. Tenant-safe lookup placeholder.</p></div><div className="studio-context-card"><small>RECOMMENDED SCRIPTS</small><ul><li>Confirm preferred date and time</li><li>Verify calendar availability before confirming</li><li>Offer manager handover if requested</li></ul></div><div className="studio-queue"><div><small>WAITING QUEUE</small><b>3</b></div><div><small>OLDEST WAIT</small><b>01:14</b></div><span>Demo metrics</span></div></div></div>
        </div>
        <form className="studio-evolution" onSubmit={proposeStudioEvolution}><div><span className="studio-kicker">PROMPT EVOLUTION</span><h2>Performance-based prompt proposal</h2><p>Uses Gemini only when configured. New prompts remain pending review; no automatic live rewrite.</p></div><div className="studio-evolution-fields"><label>Failure log<input value={studioMetrics.failure} onChange={(e) => setStudioMetrics({...studioMetrics, failure:e.target.value})} placeholder="Observed failure (optional)" /></label><label>Missed prompt<input value={studioMetrics.missed} onChange={(e) => setStudioMetrics({...studioMetrics, missed:e.target.value})} placeholder="Missed customer intent (optional)" /></label><label>Bottleneck<input value={studioMetrics.bottleneck} onChange={(e) => setStudioMetrics({...studioMetrics, bottleneck:e.target.value})} placeholder="Conversation bottleneck (optional)" /></label><label>AHT seconds<input type="number" min="0" max="86400" value={studioMetrics.aht} onChange={(e) => setStudioMetrics({...studioMetrics, aht:e.target.value})} /></label></div><button className="studio-primary" disabled={busy || !studioPodId}>Generate proposal</button>
          {studioEvolution && <div className="studio-proposal"><div><b>Proposal · {studioEvolution.status}</b><p>{studioEvolution.proposed_prompt}</p><small>Active prompt changed: {String(studioEvolution.active_prompt_changed)}</small></div><div className="studio-proposal-actions"><button type="button" className="studio-primary" disabled={busy} onClick={() => void reviewStudioEvolution(true)}>Approve & apply</button><button type="button" className="studio-secondary" disabled={busy} onClick={() => void reviewStudioEvolution(false)}>Reject</button></div></div>}
        </form>
        <div className="studio-compliance"><b>Operational-only policy</b><p>This studio is for bookings, scheduling, logistics and business operations. It excludes medical LIMS accession codes, tube/vial processing, sample tracking, lab-record interpretation, symptom interpretation and clinical advice.</p></div>
      </section>}

      {section === "Knowledge" && <section className="page">
        <div className="eyebrow">RETRIEVAL-AUGMENTED GENERATION</div><h1 className="page-title">Knowledge</h1><p className="page-lede">Index text into the selected project’s current RAG store, then test retrieval. Use a project with data you are comfortable storing locally.</p>
        {!selected && <div className="inline-warning">Select a project from the left sidebar before indexing or searching. RAG is stored in SQLite with per-user/project isolation and source version history. Configure backups before production use.</div>}
        <div className="two-column">
          <form className="surface-card form-card" onSubmit={indexKnowledge}><div className="card-heading"><span className="project-icon">＋</span><div><b>Index knowledge</b><small>Add a text source to this project's RAG index.</small></div></div><label>Source name<input value={ragSource} onChange={(event) => setRagSource(event.target.value)} placeholder="e.g. project-notes.txt" required /></label><label>Tags (comma separated)<input value={ragTags} onChange={(event) => setRagTags(event.target.value)} placeholder="e.g. product, security, requirements" /></label><label>Text content<textarea value={ragText} onChange={(event) => setRagText(event.target.value)} placeholder="Paste the knowledge you want GIA to retrieve…" rows={7} required /></label><button className="primary" disabled={busy || !selected}>Index text</button><div className="card-heading"><div><b>Indexed sources</b><small>Re-indexing a source preserves the previous version.</small></div></div><div className="result-list">{ragDocuments.map((doc) => <div className="retrieval-item" key={doc.id}><b>{doc.source}</b><p>Version {doc.version} · {doc.character_count} characters · {(doc.tags || []).join(", ") || "No tags"}</p><button className="secondary" type="button" onClick={() => void loadRagHistory(doc.source)}>View version history</button></div>)}{!ragDocuments.length && <div className="muted">No sources indexed for this project yet.</div>}{ragHistory.length > 0 && <div className="retrieval-item"><b>Version history</b>{ragHistory.map((version) => <p key={version.version}>v{version.version} · {version.character_count} characters {version.current ? "· current" : ""}</p>)}</div>}</div></form>
          <form className="surface-card form-card" onSubmit={searchKnowledge}><div className="card-heading"><span className="project-icon">⌕</span><div><b>Test retrieval</b><small>Search indexed chunks in the selected project.</small></div></div><label>Search query<input value={ragQuery} onChange={(event) => setRagQuery(event.target.value)} placeholder="What should the system recall?" required /></label><button className="secondary" disabled={busy || !selected}>Search knowledge</button><div className="result-list">{ragResults.map((item, index) => <div className="retrieval-item" key={item.id || index}><b>{item.source || item.title || `Result ${index + 1}`}</b><p>{item.text || item.content || JSON.stringify(item)}</p><small>Relevance: {item.score ?? item.similarity ?? "not provided"}</small></div>)}{!ragResults.length && <div className="muted">Search results will appear here.</div>}</div></form>
        </div>
      </section>}

      {section === "Memory" && <section className="page">
        <div className="eyebrow">PERSONAL CONTEXT</div><h1 className="page-title">Memory</h1><p className="page-lede">Save and search project-scoped notes. This interface uses the current GIA memory API; it does not automatically import old memories from another installation.</p>
        {!selected && <div className="inline-warning">Select a project from the left sidebar before saving or searching memory. Memory is stored in SQLite with per-user/project isolation, tags, summaries and importance-aware recall. Configure backups before production use.</div>}
        <div className="two-column">
          <form className="surface-card form-card" onSubmit={saveMemory}><div className="card-heading"><span className="project-icon">✧</span><div><b>Save a memory</b><small>Store a note in the selected project's current memory store.</small></div></div><label>Memory text<textarea value={memoryText} onChange={(event) => setMemoryText(event.target.value)} placeholder="Write a preference, project decision or useful fact…" rows={6} required /></label><label>Tags (comma separated)<input value={memoryTags} onChange={(event) => setMemoryTags(event.target.value)} placeholder="e.g. decision, product, safety" /></label><label>Importance<select value={memoryImportance} onChange={(event) => setMemoryImportance(Number(event.target.value))}><option value={1}>1 · Low</option><option value={2}>2</option><option value={3}>3 · Normal</option><option value={4}>4</option><option value={5}>5 · Critical</option></select></label><button className="primary" disabled={busy || !selected}>Save memory</button></form>
          <form className="surface-card form-card" onSubmit={searchMemory}><div className="card-heading"><span className="project-icon">⌕</span><div><b>Recall memory</b><small>Search saved memories and related RAG context.</small></div></div><label>What should GIA remember?<input value={memoryQuery} onChange={(event) => setMemoryQuery(event.target.value)} placeholder="Search a saved fact or decision…" required /></label><button className="secondary" disabled={busy || !selected}>Search memory</button><div className="result-list">{memoryResults.map((item, index) => <div className="retrieval-item" key={item.id || index}><b>{item.kind || item.source || `Memory ${index + 1}`}</b><p>{item.text || item.content || JSON.stringify(item)}</p><small>Importance {item.importance ?? 1} · {(item.tags || []).join(", ") || "No tags"}</small></div>)}{!memoryResults.length && <div className="muted">Memory search results will appear here.</div>}</div></form>
        </div>
      </section>}

      {section === "Settings" && <section className="page">
        <div className="eyebrow">SYSTEM CONFIGURATION</div><h1 className="page-title">Settings & health</h1><p className="page-lede">Check the current API and persistence mode. This page reports what the backend says; it does not infer production readiness from a running server alone.</p>
        <div className="button-row"><button className="secondary" disabled={busy} onClick={() => void loadSystemStatus()}>↻ Check system status</button><button className="secondary" disabled={busy} onClick={() => void loadHermesStatus()}>Check Hermes bridge</button></div>
        <div className="settings-grid">{systemStatus ? <>
          <div className="surface-card status-card"><small>API HEALTH</small><b className={systemStatus.health?.status === "healthy" ? "green" : "warning"}>{systemStatus.health?.status || "Unknown"}</b><p>Response from the FastAPI health endpoint.</p></div>
          <div className="surface-card status-card"><small>PROJECT STORAGE</small><b>{systemStatus.persistence?.backend || "Unknown"}</b><p>SQLite also stores users, tasks, approvals, execution records, RAG chunks and project memories. Check the configured database path and test backups before production use.</p></div>
        </> : <div className="empty-card"><b>Status not checked yet</b><p>Run a health and persistence check to see the backend's current report.</p><button className="secondary" onClick={() => void loadSystemStatus()}>Check status</button></div>}
          <div className="surface-card status-card"><small>HERMES BRIDGE</small><b className={hermesStatus?.reachable ? "green" : "warning"}>{!hermesStatus ? "Not checked" : hermesStatus.reachable ? "Reachable" : hermesStatus.configured ? "Configured · unreachable" : "Disabled"}</b><p>{hermesStatus?.mode === "handoff-only" ? "Optional handoff-only integration. Remote execution still requires approval in Hermes." : "Hermes is isolated and remains disabled until its bridge URL and token are configured."}</p></div>
        </div>
        <div className="surface-card intro-reset"><div><b>Introduction</b><p>Replay the short welcome flow on this browser.</p></div><button className="secondary" onClick={() => { localStorage.removeItem("gia_intro_complete"); setIntroComplete(false); }}>View introduction</button></div>
      </section>}
    </main>

    <aside className="activity">
      <div className="act-head"><div><div className="eyebrow">SYSTEM FEED</div><h3>Recent activity</h3></div><span className="activity-indicator">●</span></div>
      <div className="activity-context"><small>ACTIVE PROJECT</small><b>{activeProject?.name || "No project selected"}</b><span>{activity.length} recent events available</span></div>
      <div className="events">{activity.length ? activity.slice(0, 24).map((item, index) => <div className="event" key={`${item.type || item.event_type || "event"}-${index}`}><i /><div><b>{item.type || item.event_type || "EVENT"}</b><small>{JSON.stringify(item.payload || {}).slice(0, 180)}</small></div></div>) : <div className="empty">No recent activity returned by the API.</div>}</div>
      <div className="activity-footer"><span className="online">● API polling active</span><small>Refreshes every 5 seconds</small></div>
    </aside>
    <nav className="mobile-bottom-nav" aria-label="Mobile navigation">
      <button onClick={() => { setSection("Home"); window.history.pushState({}, "", "/"); }}>Home</button>
      <button onClick={() => { setSection("Projects"); window.history.pushState({}, "", "/"); }}>Projects</button>
      <button className="mobile-dashboard-fab" aria-label="Open central dashboard" onClick={() => { setSection("Home"); window.history.pushState({}, "", "/"); }}>⌂</button>
      <button onClick={() => { setSection("Studio"); window.history.pushState({}, "", "/studio"); }}>Studio</button>
      <button onClick={() => { setSection("Agents"); window.history.pushState({}, "", "/"); }}>Agents</button>
    </nav>
  </div>;
}

createRoot(document.getElementById("root")!).render(<React.StrictMode><App /></React.StrictMode>);
