# GIA Release Verification

Keep `GIA-VERIFY.ps1` in the GIA project root beside `backend`, `frontend`, and `GOVERNANCE`.

The script installs the exact frontend lockfile dependencies, builds the production frontend, runs Python syntax checks, and runs the complete backend pytest suite. It writes a timestamped report into the project root.

A passing script means the local automated checks passed on that computer. It does **not** certify that a live Hermes bridge, external model provider, production deployment, or backup/restore setup is working. Those are separate acceptance checks.

On Windows, open PowerShell in the project root and run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\GIA-VERIFY.ps1
```

If network access is unavailable, `npm ci` may fail because packages cannot be downloaded; that is a dependency-install failure, not proof of a frontend source defect.
