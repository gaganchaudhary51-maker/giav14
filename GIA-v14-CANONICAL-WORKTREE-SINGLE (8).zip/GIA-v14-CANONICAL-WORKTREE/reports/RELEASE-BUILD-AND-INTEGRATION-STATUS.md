# GIA v14 — Release Build & Integration Status

## Verified in this workspace
- Canonical GIA backend regression suite: **145 passed**.
- HRGEN voice integration slice: **8 passed**.
- Python syntax compilation: PASS for both backend trees.
- Scheduler tests cover explicit payloads, disabled-by-default configuration, and rejection of non-TLS remote callbacks.
- Voice webhook authentication helper fails closed in production when the token is missing; audio reads are bounded to 15 MiB + 1 byte before rejection.
- Existing provider-secret non-disclosure, task lifecycle, Studio, persistence, voice governance and release integration tests remain passing.
- ZIP integrity: verified after final packaging.
- Only `.env.example` templates are included; no `.env` credential file is packaged.

## Not verified / blocked
- Frontend production build: **BLOCKED**. `npm ci` did not complete within the available execution window; `npm run build` then failed because TypeScript type packages (including React types) were absent from the incomplete `node_modules`. Do not treat this as a passing build.
- Docker image / Compose runtime: not tested because Docker is unavailable in this execution environment.
- Live GIA LLM provider and Supabase: skipped because credentials/endpoints are not configured.
- Groq STT, Gemini voice generation, and Kokoro TTS: no provider-backed end-to-end test was possible without configured credentials/services.
- SIP/VoIP: no live call or audio stream was initiated.
- WhatsApp: no real message was sent. Existing GIA endpoint is template rendering only.
- Sub-200 ms latency and cost targets: not measured and not claimed.
- Tenant RLS: SQL is a reference schema; trusted server-side tenant context and transaction enforcement still need implementation before production data is placed there.

## Async scheduled pods
`hrgen_universal_monorepo/backend/services/pod_scheduler.py` adds opt-in asynchronous interval callbacks for Swarn Auditor and Lucas Growth. They are disabled by default and require `POD_SCHEDULER_ENABLED=true`, an HTTPS callback URL (or loopback HTTP for local development), and a bearer token. Each callback receives an idempotency key and an explicit prompt. The scheduler delegates to that configured worker; it does **not** claim to invoke agent execution internally, and does not attach personal RAG/memory or tools. An actual callback worker must be configured and tested before claiming scheduled pod execution.

## Run on the target PC
1. From `giav14-main`, run `python scripts/verify-release.py`.
2. In a network-enabled terminal, run `cd frontend && npm ci && npm run build`.
3. In `hrgen_universal_monorepo`, run `docker compose config` then `docker compose up --build` after Docker is installed and local credentials are configured.
4. Configure secrets locally using `.env.example` as a reference; never commit real keys.
5. Run `python scripts/live-integration-smoke.py` for the configured GIA provider/Supabase checks. It may send one short prompt to the configured LLM but never sends WhatsApp messages or places phone calls.

Personal RAG/memory/chat data was not migrated, reset, seeded, or rewritten. This package does not automatically alter the user's Windows folder.
