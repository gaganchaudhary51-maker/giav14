# GIA v14 — Merge into the same main source tree

## Merge result
- Destination tree: `GIA-Merged-Main/giav14-main/`
- Base archive: `giav14-main.zip` (150 files)
- Studio archive: `GIA-v14-Universal-Agent-Pods-Studio.zip` (198 files)
- Final merged tree: 199 files
- Shared paths with different contents: 31; Studio version selected for these paths.
- Base-only files preserved: 1
- Studio-only files added: 49
- Merge policy: preserve base-only files, add Studio-only files, and prefer Studio files at shared-path conflicts.
- This is one merged project tree, not a second nested app. Project root remains `giav14-main`.

## Important
This merge was performed in the current workspace package. It cannot directly modify `C:\Users\pc\Desktop\giav14-main` on your Windows PC from this environment. Extract the merged ZIP into a separate temporary folder first, then back up your PC project and copy/merge the `giav14-main` contents into the existing folder.
- Personal RAG/memory data was not imported or reset by this merge. The shared code files were merged according to the policy above; review RAG/memory code changes before replacing your local code.
- Live provider, telephony, WhatsApp and Supabase credentials/connections are not verified here.

## Path conflict summary
- `.env.example` — Studio version selected
- `.gitignore` — Studio version selected
- `GIA-VERIFY.ps1` — Studio version selected
- `RUN-GIA-VERIFY.md` — Studio version selected
- `backend/app/agents/registry.py` — Studio version selected
- `backend/app/approvals/store.py` — Studio version selected
- `backend/app/auth/security.py` — Studio version selected
- `backend/app/db/store.py` — Studio version selected
- `backend/app/db/user_store.py` — Studio version selected
- `backend/app/execution/runner.py` — Studio version selected
- `backend/app/main.py` — Studio version selected
- `backend/app/memory/store.py` — Studio version selected
- `backend/app/rag/store.py` — Studio version selected
- `backend/app/routes/agents.py` — Studio version selected
- `backend/app/routes/approvals.py` — Studio version selected
- `backend/app/routes/auth.py` — Studio version selected
- `backend/app/routes/conversation.py` — Studio version selected
- `backend/app/routes/execution.py` — Studio version selected
- `backend/app/routes/memory.py` — Studio version selected
- `backend/app/routes/orchestration.py` — Studio version selected
- `backend/app/routes/rag.py` — Studio version selected
- `backend/app/routes/tasks.py` — Studio version selected
- `backend/app/services/agent_router.py` — Studio version selected
- `backend/app/tasks/store.py` — Studio version selected
- `backend/tests/test_approvals.py` — Studio version selected
- `backend/tests/test_execution_governance.py` — Studio version selected
- `backend/tests/test_persistence.py` — Studio version selected
- `frontend/src/api.ts` — Studio version selected
- `frontend/src/main.tsx` — Studio version selected
- `frontend/src/styles.css` — Studio version selected
- `frontend/vite.config.ts` — Studio version selected